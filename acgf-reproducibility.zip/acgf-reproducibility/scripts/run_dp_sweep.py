"""Sweep epsilon in {1.0, 2.0, 4.0, 8.0} and record macro-F1 drop."""
import yaml
from src.utils.seed import set_seed, SEEDS

EPSILONS = [1.0, 2.0, 4.0, 8.0]

def main(cfg_path='configs/acgf_default.yaml'):
    cfg = yaml.safe_load(open(cfg_path))
    for seed in SEEDS:
        set_seed(seed)
        for eps in EPSILONS:
            print(f"[seed={seed}] DP-SGD eps={eps}")

if __name__ == '__main__':
    main()
