import yaml, argparse
from src.utils.seed import set_seed

def main(cfg_path):
    cfg = yaml.safe_load(open(cfg_path))
    for seed in cfg['seeds']:
        set_seed(seed)
        for b in cfg['baselines']:
            print(f"[seed={seed}] training baseline: {b}")
            # plug real baseline trainers here

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='configs/baselines.yaml')
    main(ap.parse_args().config)
