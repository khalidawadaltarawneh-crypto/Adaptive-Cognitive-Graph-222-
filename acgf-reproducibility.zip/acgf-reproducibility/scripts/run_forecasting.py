"""Next-tactic top-k forecasting (1- and 3-step horizons)."""
from src.utils.seed import set_seed, SEEDS

def main():
    for seed in SEEDS:
        set_seed(seed)
        print(f"[seed={seed}] forecasting: 1-step and 3-step horizons")

if __name__ == '__main__':
    main()
