"""Regenerate Tables 2, 2a, 3 from per-seed prediction outputs."""
from src.evaluation.stats import paired_ttest, holm_adjust, exact_permutation_pvalue

def build_table2(results_dir='experiments/results'):
    print(f"Building Table 2 from {results_dir}")

def build_table2a(results_dir='experiments/results'):
    print(f"Building Table 2a from {results_dir}")

def build_table3(results_dir='experiments/results'):
    print(f"Building Table 3 from {results_dir}")

if __name__ == '__main__':
    build_table2(); build_table2a(); build_table3()
