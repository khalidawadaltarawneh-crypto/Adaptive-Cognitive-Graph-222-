import argparse, yaml, torch
from src.utils.seed import set_seed
from src.models.acgf import ACGF
from src.federated.server import FederatedServer
from src.privacy.dp_sgd import DPSGD
from src.optimization.pruning import structured_prune

def main(cfg_path, seed):
    cfg = yaml.safe_load(open(cfg_path))
    set_seed(seed)
    device = cfg['project']['device']
    model = ACGF(cfg).to(device)
    server = FederatedServer(model, cfg)
    dp = DPSGD(**{k: v for k, v in cfg['privacy'].items() if k != 'rdp_orders'})
    for r in range(cfg['federated']['rounds']):
        # --- replace with real client dataloaders ---
        updates = []
        server.aggregate(updates if updates else [server.global_model.state_dict()])
        if (r + 1) % cfg['optimization']['pruning']['every_n_rounds'] == 0:
            structured_prune(server.global_model,
                             cfg['optimization']['pruning']['sparsity'])
    torch.save(server.global_model.state_dict(),
               f'experiments/results/acgf_seed{seed}.pt')

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='configs/acgf_default.yaml')
    ap.add_argument('--seed', type=int, default=42)
    args = ap.parse_args()
    main(args.config, args.seed)
