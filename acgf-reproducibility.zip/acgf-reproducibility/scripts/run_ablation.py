"""Reproduces Table 3: ablations on DAPT2020."""
import yaml
from src.utils.seed import set_seed, SEEDS

VARIANTS = ["Full ACGF", "w/o GCT", "w/o TIKG", "w/o Trust RL", "w/o ACT + pruning"]

def main(cfg_path='configs/acgf_default.yaml'):
    cfg = yaml.safe_load(open(cfg_path))
    for seed in SEEDS:
        set_seed(seed)
        for v in VARIANTS:
            print(f"[seed={seed}] ablation: {v}")

if __name__ == '__main__':
    main()
