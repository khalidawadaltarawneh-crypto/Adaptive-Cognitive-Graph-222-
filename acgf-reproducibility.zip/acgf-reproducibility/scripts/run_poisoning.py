"""Sign-flipping and gradient-scaling attacks with 10% malicious clients."""
from src.utils.seed import set_seed, SEEDS

MALICIOUS_FRACTION = 0.10
ROUNDS = 100

def main():
    for seed in SEEDS:
        set_seed(seed)
        print(f"[seed={seed}] poisoning run: {MALICIOUS_FRACTION*100:.0f}% malicious clients")

if __name__ == '__main__':
    main()
