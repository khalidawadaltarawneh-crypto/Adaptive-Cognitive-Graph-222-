import torch
import torch.nn as nn

class FederatedClient:
    def __init__(self, client_id, model, dataloader, cfg, device='cuda'):
        self.client_id = client_id
        self.model = model
        self.loader = dataloader
        self.cfg = cfg
        self.device = device
        self.trust_score = 1.0

    def local_train(self, global_state, epochs=2):
        self.model.load_state_dict(global_state)
        self.model.to(self.device).train()
        opt = torch.optim.AdamW(
            self.model.parameters(),
            lr=self.cfg['training']['lr'],
            weight_decay=self.cfg['training']['weight_decay'])
        for _ in range(epochs):
            for batch in self.loader:
                x, edge_index, batch_seq, sym_ids, y = [b.to(self.device) for b in batch]
                opt.zero_grad()
                logits, align_loss, _ = self.model(x, edge_index, batch_seq, sym_ids)
                loss = nn.functional.cross_entropy(logits, y) + align_loss
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                opt.step()
        return {k: v.cpu() for k, v in self.model.state_dict().items()}
