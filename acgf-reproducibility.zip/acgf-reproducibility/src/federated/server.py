import torch
from collections import OrderedDict

class FederatedServer:
    def __init__(self, model, cfg):
        self.global_model = model
        self.cfg = cfg
        self.round = 0

    def aggregate(self, client_updates, weights=None):
        if weights is None:
            weights = [1.0] * len(client_updates)
        total = sum(weights)
        global_dict = self.global_model.state_dict()
        new_dict = OrderedDict()
        for k in global_dict.keys():
            new_dict[k] = sum(w * u[k].float()
                              for w, u in zip(weights, client_updates)) / total
        self.global_model.load_state_dict(new_dict)
        self.round += 1
        return self.global_model
