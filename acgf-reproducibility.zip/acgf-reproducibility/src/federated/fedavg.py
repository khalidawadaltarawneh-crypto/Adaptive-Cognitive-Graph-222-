"""FedAvg / FedProx helpers."""
import torch

def fedprox_penalty(local_params, global_params, mu=0.01):
    penalty = 0.0
    for lp, gp in zip(local_params, global_params):
        penalty += ((lp - gp) ** 2).sum()
    return 0.5 * mu * penalty
