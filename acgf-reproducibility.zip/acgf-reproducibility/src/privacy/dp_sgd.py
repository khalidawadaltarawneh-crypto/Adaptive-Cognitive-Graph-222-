import math
import torch

class DPSGD:
    """Subsampled Gaussian mechanism with approximate RDP accounting."""
    def __init__(self, clip_norm=1.0, noise_multiplier=0.8, delta=1e-5,
                 target_epsilon=2.0, sample_rate=0.001953125, orders=None, **_):
        self.clip_norm = clip_norm
        self.noise_multiplier = noise_multiplier
        self.delta = delta
        self.target_epsilon = target_epsilon
        self.sample_rate = sample_rate
        self.orders = orders or [1.25, 1.5, 1.75, 2, 3, 4, 5, 6, 7, 8, 16, 32, 64]

    def privatize(self, model):
        for p in model.parameters():
            if p.grad is None:
                continue
            norm = p.grad.norm(2)
            if norm > self.clip_norm:
                p.grad.mul_(self.clip_norm / (norm + 1e-12))
            p.grad.add_(torch.randn_like(p.grad) * self.noise_multiplier * self.clip_norm)
        return model

    def compute_rdp(self, steps):
        eps = 0.0
        for alpha in self.orders:
            rdp = steps * (self.sample_rate ** 2) / (2 * self.noise_multiplier ** 2) * alpha
            eps = max(eps, rdp + math.log(1 / self.delta) / (alpha - 1))
        return min(eps, self.target_epsilon), self.delta
