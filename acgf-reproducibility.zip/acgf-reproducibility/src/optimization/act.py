import torch

class AdaptiveComputationTime:
    def __init__(self, confidence_threshold=0.9, **_):
        self.threshold = confidence_threshold

    def should_exit(self, logits):
        conf = torch.softmax(logits, dim=-1).max(dim=-1).values
        return bool(conf.mean() >= self.threshold)
