import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.utils.prune as prune

def structured_prune(model, amount=0.2):
    for _, module in model.named_modules():
        if isinstance(module, (nn.Linear, nn.Conv2d)):
            prune.ln_structured(module, name='weight', amount=amount, n=1, dim=0)
            prune.remove(module, 'weight')
    return model

def distill_loss(student_logits, teacher_logits, T=2.0):
    return F.kl_div(
        F.log_softmax(student_logits / T, dim=-1),
        F.softmax(teacher_logits / T, dim=-1),
        reduction='batchmean') * (T * T)
