import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv

class GCNBiLSTMEncoder(nn.Module):
    """Spatio-temporal encoder: 2-layer GCN + BiLSTM -> 64-d latent."""
    def __init__(self, in_dim, gcn_hidden=128, gcn_layers=2,
                 bilstm_hidden=64, latent_dim=64, dropout=0.2):
        super().__init__()
        self.convs = nn.ModuleList([GCNConv(in_dim, gcn_hidden)])
        for _ in range(gcn_layers - 1):
            self.convs.append(GCNConv(gcn_hidden, gcn_hidden))
        self.bilstm = nn.LSTM(gcn_hidden, bilstm_hidden,
                              batch_first=True, bidirectional=True)
        self.dropout = nn.Dropout(dropout)
        self.proj = nn.Sequential(
            nn.Linear(bilstm_hidden * 2, latent_dim),
            nn.BatchNorm1d(latent_dim),
            nn.ReLU(),
            nn.Linear(latent_dim, latent_dim),
        )

    def forward(self, x, edge_index, batch_seq):
        h = x
        for conv in self.convs:
            h = F.relu(conv(h, edge_index))
            h = self.dropout(h)
        b, t, n, d = batch_seq.shape
        seq = batch_seq.reshape(b, t, n * d)
        lstm_out, _ = self.bilstm(seq)
        return self.proj(lstm_out[:, -1, :])
