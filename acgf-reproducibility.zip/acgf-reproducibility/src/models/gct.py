import torch
import torch.nn as nn
import torch.nn.functional as F

class GraphContrastiveTransformer(nn.Module):
    def __init__(self, neural_dim=64, symbolic_dim=64, hidden_dim=128,
                 num_heads=4, num_layers=2, ff_expansion=2, temperature=0.07):
        super().__init__()
        self.temperature = temperature
        self.neural_proj = nn.Linear(neural_dim, hidden_dim)
        self.symbolic_proj = nn.Linear(symbolic_dim, hidden_dim)
        enc = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=num_heads,
            dim_feedforward=hidden_dim * ff_expansion,
            batch_first=True, dropout=0.1)
        self.transformer = nn.TransformerEncoder(enc, num_layers=num_layers)
        self.align = nn.Linear(hidden_dim, hidden_dim)

    def forward(self, z_neural, s_symbolic):
        zn = self.neural_proj(z_neural).unsqueeze(1)
        zs = self.symbolic_proj(s_symbolic).unsqueeze(1)
        fused = torch.cat([zn, zs], dim=1)
        out = self.transformer(fused)
        zn_a = F.normalize(self.align(out[:, 0]), dim=-1)
        zs_a = F.normalize(out[:, 1], dim=-1)
        logits = zn_a @ zs_a.t() / self.temperature
        labels = torch.arange(zn_a.size(0), device=zn_a.device)
        loss = F.cross_entropy(logits, labels)
        return loss, zn_a, zs_a
