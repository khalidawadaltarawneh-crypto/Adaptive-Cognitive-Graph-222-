import torch
import torch.nn as nn

class TrustAgent(nn.Module):
    def __init__(self, state_dim=6, action_dim=3, hidden=128):
        super().__init__()
        self.backbone = nn.Sequential(
            nn.Linear(state_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
        )
        self.actor = nn.Linear(hidden, action_dim)
        self.critic = nn.Linear(hidden, 1)

    def forward(self, state):
        h = self.backbone(state)
        return self.actor(h), self.critic(h)

    def act(self, state, deterministic=False):
        logits, value = self.forward(state)
        probs = torch.softmax(logits, dim=-1)
        action = torch.argmax(probs, dim=-1) if deterministic \
                 else torch.multinomial(probs, 1).squeeze(-1)
        log_prob = torch.log_softmax(logits, dim=-1).gather(-1, action.unsqueeze(-1))
        return action, log_prob.squeeze(-1), value.squeeze(-1)
