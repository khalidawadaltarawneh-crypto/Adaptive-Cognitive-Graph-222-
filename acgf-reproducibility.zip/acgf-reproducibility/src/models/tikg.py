import torch
import torch.nn as nn

class ThreatIntelligenceKnowledgeGraph(nn.Module):
    """RotatE-style symbolic embedding of MITRE ATT&CK entities/relations."""
    def __init__(self, num_entities, num_relations, embedding_dim=64, gamma=12.0):
        super().__init__()
        self.entity_emb = nn.Embedding(num_entities, embedding_dim * 2)
        self.relation_emb = nn.Embedding(num_relations, embedding_dim)
        self.gamma = gamma
        nn.init.uniform_(self.entity_emb.weight, -0.1, 0.1)
        nn.init.uniform_(self.relation_emb.weight, -0.1, 0.1)

    def score(self, head, rel, tail):
        h = self.entity_emb(head)
        r = self.relation_emb(rel)
        t = self.entity_emb(tail)
        h_re, h_im = h.chunk(2, dim=-1)
        t_re, t_im = t.chunk(2, dim=-1)
        r_re, r_im = torch.cos(r), torch.sin(r)
        re = h_re * r_re - h_im * r_im
        im = h_re * r_im + h_im * r_re
        return self.gamma - torch.norm(re - t_re, p=1, dim=-1) - torch.norm(im - t_im, p=1, dim=-1)

    def get_embedding(self, entity_ids):
        return self.entity_emb(entity_ids)
