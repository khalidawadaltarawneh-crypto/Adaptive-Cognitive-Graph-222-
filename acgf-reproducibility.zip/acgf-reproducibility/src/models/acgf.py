import torch
import torch.nn as nn
from .gcn_bilstm import GCNBiLSTMEncoder
from .gct import GraphContrastiveTransformer
from .tikg import ThreatIntelligenceKnowledgeGraph
from .trust_agent import TrustAgent

class ACGF(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.encoder = GCNBiLSTMEncoder(
            in_dim=cfg['graph']['node_feature_dim'],
            gcn_hidden=cfg['model']['gcn_hidden'],
            gcn_layers=cfg['model']['gcn_layers'],
            bilstm_hidden=cfg['model']['bilstm_hidden'],
            latent_dim=cfg['model']['latent_dim'],
            dropout=cfg['model']['dropout'])
        self.gct = GraphContrastiveTransformer(
            neural_dim=cfg['model']['latent_dim'],
            symbolic_dim=cfg['tikg']['embedding_dim'],
            hidden_dim=cfg['gct']['hidden_dim'],
            num_heads=cfg['gct']['num_heads'],
            num_layers=cfg['gct']['num_layers'],
            ff_expansion=cfg['gct']['ff_expansion'],
            temperature=cfg['gct']['temperature'])
        self.tikg = ThreatIntelligenceKnowledgeGraph(
            num_entities=cfg['tikg'].get('num_entities', 1000),
            num_relations=cfg['tikg'].get('num_relations', 100),
            embedding_dim=cfg['tikg']['embedding_dim'])
        self.trust = TrustAgent(state_dim=6, action_dim=3)
        self.classifier = nn.Linear(cfg['model']['latent_dim'], 2)

    def forward(self, x, edge_index, batch_seq, symbolic_ids):
        z_neural = self.encoder(x, edge_index, batch_seq)
        s_symbolic = self.tikg.get_embedding(symbolic_ids)
        loss_align, zn_a, _ = self.gct(z_neural, s_symbolic)
        logits = self.classifier(zn_a)
        return logits, loss_align, z_neural
