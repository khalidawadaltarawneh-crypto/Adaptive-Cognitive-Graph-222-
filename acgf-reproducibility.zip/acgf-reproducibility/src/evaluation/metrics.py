import numpy as np
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

def compute_metrics(y_true, y_pred, y_prob):
    return {
        'accuracy': accuracy_score(y_true, y_pred),
        'macro_f1': f1_score(y_true, y_pred, average='macro'),
        'auroc': roc_auc_score(y_true, y_prob),
    }

def top_k_accuracy(logits, targets, k=1):
    topk = np.argsort(-logits, axis=-1)[:, :k]
    return float(np.mean([t in row for t, row in zip(targets, topk)]))
