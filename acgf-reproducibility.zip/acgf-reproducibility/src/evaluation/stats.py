import numpy as np
from scipy import stats
from itertools import product

def paired_ttest(a, b):
    t, p = stats.ttest_rel(a, b)
    diff = np.array(a) - np.array(b)
    n = len(diff)
    se = diff.std(ddof=1) / np.sqrt(n)
    ci = stats.t.ppf(0.975, df=n - 1) * se
    return {'mean_diff': diff.mean(),
            'ci95': (diff.mean() - ci, diff.mean() + ci),
            't': t, 'p': p, 'n': n, 'df': n - 1}

def holm_adjust(pvals):
    pvals = np.array(pvals)
    order = np.argsort(pvals)
    adjusted = np.empty_like(pvals)
    m = len(pvals)
    running_max = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * pvals[idx]
        running_max = max(running_max, val)
        adjusted[idx] = min(running_max, 1.0)
    return adjusted

def exact_permutation_pvalue(diffs):
    diffs = np.array(diffs)
    n = len(diffs)
    obs = abs(diffs.mean())
    count = 0
    for signs in product([-1, 1], repeat=n):
        if abs((diffs * np.array(signs)).mean()) >= obs:
            count += 1
    return count / (2 ** n)
