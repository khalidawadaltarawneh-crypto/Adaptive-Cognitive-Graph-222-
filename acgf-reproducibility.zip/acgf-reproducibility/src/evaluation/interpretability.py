"""Attention faithfulness and TIKG-relation alignment metrics."""
import numpy as np

def attention_faithfulness(attention_weights, tikg_relations):
    """Fraction of high-weight edges corresponding to valid TTP relations."""
    high = attention_weights > np.quantile(attention_weights, 0.9)
    return float(tikg_relations[high].mean())
