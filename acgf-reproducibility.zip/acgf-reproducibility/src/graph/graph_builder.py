import torch
from sklearn.neighbors import NearestNeighbors

EDGE_TYPES = ['communication', 'invocation', 'temporal', 'semantic', 'dependency']

def build_graph(node_features, k=10):
    n = node_features.shape[0]
    if n <= 1:
        return torch.empty((2, 0), dtype=torch.long)
    nn_model = NearestNeighbors(n_neighbors=min(k, n - 1), metric='cosine').fit(node_features)
    _, indices = nn_model.kneighbors(node_features)
    src, dst = [], []
    for i in range(n):
        for j in indices[i]:
            src.extend([i, j]); dst.extend([j, i])
    return torch.tensor([src, dst], dtype=torch.long)

def temporal_window(records, window_size=10, stride=5):
    for start in range(0, len(records) - window_size + 1, stride):
        yield start, start + window_size
