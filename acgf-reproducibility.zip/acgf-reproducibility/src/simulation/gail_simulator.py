import torch
import torch.nn as nn

class GAILSimulator(nn.Module):
    def __init__(self, state_dim=64, action_dim=16, hidden=128, horizon=32):
        super().__init__()
        self.horizon = horizon
        self.generator = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, action_dim))
        self.discriminator = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden), nn.ReLU(),
            nn.Linear(hidden, 1))

    def sample(self, init_state, batch_size=64):
        state = init_state.unsqueeze(0).repeat(batch_size, 1)
        traj = []
        for _ in range(self.horizon):
            noise = torch.randn(batch_size, self.generator[0].in_features - state.size(-1))
            action = torch.tanh(self.generator(torch.cat([state, noise], dim=-1)))
            traj.append(action)
            state = state + 0.1 * action
        return torch.stack(traj, dim=1)
