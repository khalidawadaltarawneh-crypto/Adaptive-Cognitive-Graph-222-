# Methodology

## 1. Edge-Level Intelligence
Each edge node builds a local spatio-temporal graph with:
- Node features: source/dest IP, packet size, IAT, flow duration, flags, protocol, TCP window
- Edge types: communication, invocation, temporal proximity, semantic co-occurrence, dependency
- k-NN augmentation (k=10) using cosine similarity
- 2-layer GCN (128 units) + BiLSTM (64 units) + MLP projection to 64-d latent

## 2. Local Learning & Privacy
- Contrastive InfoNCE loss between neural and symbolic embeddings
- AdamW, lr=1e-3, weight_decay=1e-4, batch=128, 2 local epochs
- DP-SGD: clip L2 norm to 1.0, Gaussian noise sigma=0.8, eps=2.0, delta=1e-5
- RDP accountant over orders {1.25, 1.5, 1.75, 2, ..., 64}

## 3. Federated Cognitive Aggregation
- 40 clients, 20% participation per round, 100 rounds
- FedAvg or FedProx (mu=0.01)
- 8-bit quantization + top-20% sparsification
- TIKG updated every 5 rounds (RotatE, 64-d)

## 4. Graph Contrastive Transformer (GCT)
- Dual-attention alignment, hidden=128, heads=4, layers=2, ff=2x
- InfoNCE with temperature tau=0.07

## 5. Cognitive Trust Calibration
- PPO agent, lr=3e-4, gamma=0.99
- State: gradient variance, privacy consumption, data drift
- Actions: reweight, suspend, keep

## 6. Defense Response
- Neuro-symbolic reasoning over TIKG policy rules
- Automatic mitigation when confidence >= 0.9
- Audit trail on blockchain ledger (future work)

## 7. Resource-Aware Optimization
- ACT: early exit when confidence > 0.9 (33.0 ms -> 18.6 ms inference)
- Structured pruning: up to 20% params every 10 rounds, distillation T=2
