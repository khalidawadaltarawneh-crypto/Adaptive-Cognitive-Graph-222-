# Reproducibility Checklist

1. Clone repo, create env: `conda env create -f environment.yml`
2. Download datasets into `data/raw/`:
   - CIC-IDS2018: https://www.unb.ca/cic/datasets/ids-2018.html
   - TON_IoT: https://research.unsw.edu.au/projects/toniot-datasets
   - DAPT2020: https://github.com/dapt2020
3. Generate splits: `python data/splits/generate_splits.py`
4. Train ACGF: `python scripts/train_acgf.py`
5. Train baselines: `python scripts/train_baselines.py`
6. Ablations: `python scripts/run_ablation.py`
7. Poisoning: `python scripts/run_poisoning.py`
8. DP sweep: `python scripts/run_dp_sweep.py`
9. Forecasting: `python scripts/run_forecasting.py`
10. Tables: `python scripts/generate_tables.py`
