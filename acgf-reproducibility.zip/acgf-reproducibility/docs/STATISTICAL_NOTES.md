# Statistical Notes

- Seeds: 5 fixed (42, 123, 456, 789, 1024).
- Paired tests: two-sided paired t-tests, n=5, df=4.
- Multiple comparisons: Holm adjustment across 6 comparisons.
- Permutation: exact paired permutation over 2^5 = 32 sign assignments.
- Caveat: smallest attainable two-sided exact permutation p-value is 1/16 = 0.0625.
- CI: 95% CI via Student's t-distribution.
- No pooling across datasets or metrics.
- Report Table 2a means, 95% CIs, Holm-adjusted p, and permutation p.
