"""Chronological grouped 70/10/20 split with no leakage across partitions."""
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

def make_splits(df, group_col='campaign_id', time_col='timestamp',
                ratios=(0.7, 0.1, 0.2), seed=42):
    df = df.sort_values(time_col).reset_index(drop=True)
    gss1 = GroupShuffleSplit(n_splits=1, test_size=ratios[1] + ratios[2], random_state=seed)
    train_idx, temp_idx = next(gss1.split(df, groups=df[group_col]))
    temp = df.iloc[temp_idx]
    gss2 = GroupShuffleSplit(n_splits=1,
                             test_size=ratios[2] / (ratios[1] + ratios[2]),
                             random_state=seed)
    val_idx, test_idx = next(gss2.split(temp, groups=temp[group_col]))
    return (df.iloc[train_idx].index, temp.iloc[val_idx].index, temp.iloc[test_idx].index)

if __name__ == '__main__':
    print("Place raw datasets in data/raw/, then call make_splits(df).")
