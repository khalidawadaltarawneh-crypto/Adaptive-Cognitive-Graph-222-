import numpy as np
from src.evaluation.metrics import top_k_accuracy

def test_topk():
    logits = np.array([[0.1, 0.9, 0.0], [0.7, 0.2, 0.1]])
    targets = [1, 2]
    assert top_k_accuracy(logits, targets, k=1) == 0.5
    assert top_k_accuracy(logits, targets, k=3) == 1.0
