import torch, yaml
from src.models.acgf import ACGF

def test_forward_shape():
    cfg = yaml.safe_load(open('configs/acgf_default.yaml'))
    model = ACGF(cfg)
    x = torch.randn(20, cfg['graph']['node_feature_dim'])
    edge_index = torch.randint(0, 20, (2, 40))
    batch_seq = torch.randn(2, 10, 20, cfg['model']['gcn_hidden'])
    sym_ids = torch.randint(0, 1000, (2,))
    logits, loss, z = model(x, edge_index, batch_seq, sym_ids)
    assert logits.shape == (2, 2)
    assert loss.dim() == 0
