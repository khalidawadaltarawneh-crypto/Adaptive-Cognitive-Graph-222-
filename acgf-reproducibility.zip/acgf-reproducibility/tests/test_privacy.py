from src.privacy.dp_sgd import DPSGD

def test_rdp_budget():
    dp = DPSGD()
    eps, delta = dp.compute_rdp(steps=100)
    assert eps <= 2.0
    assert delta == 1e-5
