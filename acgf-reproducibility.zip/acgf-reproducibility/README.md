# ACGF: Adaptive Cognitive Graph Fusion for Proactive APT Defense

Official research prototype for the paper:
"Adaptive Cognitive Graph Fusion Framework for Proactive APT Defense in Federated Edge Networks"

## Overview
ACGF integrates:
- Federated graph neural learning (GCN + BiLSTM)
- Neuro-symbolic reasoning (TIKG + Graph Contrastive Transformer)
- Reinforcement-learning-based cognitive trust calibration (PPO)
- Differential privacy (DP-SGD, eps=2.0, delta=1e-5)
- Resource-aware optimization (ACT + structured pruning)

## Datasets
- CIC-IDS2018
- TON_IoT
- DAPT2020

## Quick Start
    conda env create -f environment.yml
    conda activate acgf
    python scripts/train_acgf.py --config configs/acgf_default.yaml

## Reproducing Paper Results
    python scripts/train_acgf.py --config configs/acgf_default.yaml
    python scripts/train_baselines.py --config configs/baselines.yaml
    python scripts/run_ablation.py
    python scripts/run_poisoning.py
    python scripts/run_dp_sweep.py
    python scripts/run_forecasting.py
    python scripts/generate_tables.py

## Seeds
Five fixed seeds: 42, 123, 456, 789, 1024

## Statistical Protocol
- Two-sided paired t-tests (n=5, df=4)
- Holm adjustment across 6 comparisons
- Exact paired permutation test (2^5 = 32 sign assignments)

## License
MIT
